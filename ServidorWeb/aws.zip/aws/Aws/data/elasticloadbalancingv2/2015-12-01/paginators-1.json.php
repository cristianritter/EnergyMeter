<?php
// This file was auto-generated from sdk-root/src/data/elasticloadbalancingv2/2015-12-01/paginators-1.json
return [ 'pagination' => [ 'DescribeListeners' => [ 'input_token' => 'Marker', 'output_token' => 'NextMarker', 'result_key' => 'Listeners', ], 'DescribeLoadBalancers' => [ 'input_token' => 'Marker', 'output_token' => 'NextMarker', 'result_key' => 'LoadBalancers', ], 'DescribeTargetGroups' => [ 'input_token' => 'Marker', 'output_token' => 'NextMarker', 'result_key' => 'TargetGroups', ], ],];
