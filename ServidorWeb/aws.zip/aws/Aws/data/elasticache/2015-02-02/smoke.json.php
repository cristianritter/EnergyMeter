<?php
// This file was auto-generated from sdk-root/src/data/elasticache/2015-02-02/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeEvents', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeCacheClusters', 'input' => [ 'CacheClusterId' => 'fake_cluster', ], 'errorExpectedFromService' => true, ], ],];
