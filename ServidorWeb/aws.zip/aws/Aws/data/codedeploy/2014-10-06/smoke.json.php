<?php
// This file was auto-generated from sdk-root/src/data/codedeploy/2014-10-06/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListApplications', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetDeployment', 'input' => [ 'deploymentId' => 'd-USUAELQEX', ], 'errorExpectedFromService' => true, ], ],];
